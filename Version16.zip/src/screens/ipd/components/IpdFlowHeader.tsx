'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { Box, Button, Chip, Stack, Typography } from '@/src/ui/components/atoms';
import { Card } from '@/src/ui/components/molecules';
import { useTheme } from '@mui/material';
import { getSoftSurface } from '@/src/core/theme/surfaces';
import { ArrowForward as ArrowForwardIcon } from '@mui/icons-material';
import { IPD_FLOW_STEPS, IpdFlowStepId, getIpdFlowStepIndex } from '../ipd-flow-config';

interface IpdFlowHeaderProps {
  activeStep: IpdFlowStepId;
  title: string;
  description: string;
  patientMrn?: string;
  primaryAction?: {
    label: string;
    route: string;
  };
}

export default function IpdFlowHeader({
  activeStep,
  title,
  description,
  patientMrn,
  primaryAction,
}: IpdFlowHeaderProps) {
  const router = useRouter();
  const theme = useTheme();
  const softSurface = getSoftSurface(theme);
  const activeIndex = getIpdFlowStepIndex(activeStep);
  const mrnSuffix = patientMrn ? `?mrn=${encodeURIComponent(patientMrn)}` : '';
  const withMrn = (route: string) => (patientMrn ? `${route}${mrnSuffix}` : route);

  return (
    <Card
      elevation={0}
      sx={{
        p: { xs: 2, sm: 2 },
        borderRadius: 2.5,
        border: '1px solid',
        borderColor: 'divider',
        backgroundColor: softSurface,
      }}
    >
      <Stack spacing={2}>
        <Stack
          direction={{ xs: 'column', md: 'row' }}
          spacing={1.5}
          alignItems={{ xs: 'flex-start', md: 'center' }}
          justifyContent="space-between"
        >
          <Box>
            <Stack direction="row" spacing={1} flexWrap="wrap" sx={{ mb: 1 }}>
              <Chip size="small" color="primary" label="IPD Workflow" />
              <Chip size="small" color="info" variant="outlined" label="Admissions to Discharge" />
            </Stack>
            <Typography variant="h6" sx={{ fontWeight: 700 }}>
              {title}
            </Typography>
            <Typography variant="body1" color="text.secondary">
              {description}
            </Typography>
          </Box>

          {primaryAction ? (
            <Button
              variant="contained"
              endIcon={<ArrowForwardIcon />}
              onClick={() => router.push(withMrn(primaryAction.route))}
            >
              {primaryAction.label}
            </Button>
          ) : null}
        </Stack>

        <Stack direction="row" spacing={1} flexWrap="wrap">
          {IPD_FLOW_STEPS.map((step, index) => {
            const isActive = step.id === activeStep;
            const isCompleted = index < activeIndex;
            return (
              <Button
                key={step.id}
                variant={isActive ? 'contained' : 'outlined'}
                color={'primary'}
                size="small"
                onClick={() => router.push(withMrn(step.route))}
                sx={{
                  textTransform: 'none',
                  fontWeight: 600,
                  borderStyle: isActive ? 'solid' : 'dashed',
                }}
              >
                {index + 1}. {step.label}
              </Button>
            );
          })}
        </Stack>
      </Stack>
    </Card>
  );
}
