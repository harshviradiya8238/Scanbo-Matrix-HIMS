import PageTemplate from '@/src/ui/components/PageTemplate';

export default function FacilityPage() {
  return <PageTemplate title="Facility Settings" currentPageTitle="Facility" />;
}
