import PageTemplate from '@/src/ui/components/PageTemplate';

export default function DepartmentsPage() {
  return <PageTemplate title="Departments" currentPageTitle="Departments" />;
}
