import PageTemplate from '@/src/ui/components/PageTemplate';

export default function ClinicalReportsPage() {
  return <PageTemplate title="Clinical Reports" currentPageTitle="Clinical Reports" />;
}
