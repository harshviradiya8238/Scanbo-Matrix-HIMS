import PageTemplate from '@/src/ui/components/PageTemplate';

export default function RadiologyOrdersPage() {
  return <PageTemplate title="Radiology Orders" currentPageTitle="Radiology Orders" />;
}
