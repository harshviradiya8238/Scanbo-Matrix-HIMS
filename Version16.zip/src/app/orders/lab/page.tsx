import PageTemplate from '@/src/ui/components/PageTemplate';

export default function LabOrdersPage() {
  return <PageTemplate title="Lab Orders" currentPageTitle="Lab Orders" />;
}
