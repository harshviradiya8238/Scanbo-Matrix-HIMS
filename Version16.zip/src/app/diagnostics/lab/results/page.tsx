import PageTemplate from '@/src/ui/components/PageTemplate';

export default function ResultsPage() {
  return <PageTemplate title="Lab Results" currentPageTitle="Results" />;
}
