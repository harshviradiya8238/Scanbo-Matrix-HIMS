import PageTemplate from '@/src/ui/components/PageTemplate';

export default function ReportsPage() {
  return <PageTemplate title="Radiology Reports" currentPageTitle="Reports" />;
}
