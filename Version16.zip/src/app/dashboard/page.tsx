import DashboardPage from '@/src/screens/dashboard/DashboardPage';

export default function DashboardRoutePage() {
  return <DashboardPage />;
}
