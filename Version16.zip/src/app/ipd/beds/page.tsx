import IpdBedManagementPage from '@/src/screens/ipd/IpdBedManagementPage';

export default function BedsPage() {
  return <IpdBedManagementPage />;
}
