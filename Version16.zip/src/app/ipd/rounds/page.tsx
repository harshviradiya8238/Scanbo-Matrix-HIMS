import InpatientClinDocPage from '@/src/screens/clinical/InpatientClinDocPage';

export default function RoundsPage() {
  return <InpatientClinDocPage />;
}
