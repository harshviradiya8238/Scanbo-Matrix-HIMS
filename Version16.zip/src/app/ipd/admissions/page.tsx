import IpdAdmissionsPage from '@/src/screens/ipd/IpdAdmissionsPage';

export default function AdmissionsPage() {
  return <IpdAdmissionsPage />;
}
