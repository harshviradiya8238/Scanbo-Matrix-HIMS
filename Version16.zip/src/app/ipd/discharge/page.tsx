import IpdDischargePage from '@/src/screens/ipd/IpdDischargePage';

export default function DischargePage() {
  return <IpdDischargePage />;
}
