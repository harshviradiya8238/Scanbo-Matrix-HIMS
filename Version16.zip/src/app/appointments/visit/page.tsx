import OpdVisitPage from '@/src/screens/opd/OpdVisitPage';

export default function VisitPage() {
  return <OpdVisitPage />;
}
