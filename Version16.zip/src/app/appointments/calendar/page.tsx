import OpdCalendarPage from '@/src/screens/opd/OpdCalendarPage';

export default function CalendarPage() {
  return <OpdCalendarPage />;
}
