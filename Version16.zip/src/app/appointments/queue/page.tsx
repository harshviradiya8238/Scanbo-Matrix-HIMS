import OpdQueuePage from '@/src/screens/opd/OpdQueuePage';

export default function QueuePage() {
  return <OpdQueuePage />;
}
