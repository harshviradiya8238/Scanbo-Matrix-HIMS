import PageTemplate from '@/src/ui/components/PageTemplate';

export default function PaymentsPage() {
  return <PageTemplate title="Billing Payments" currentPageTitle="Payments" />;
}
