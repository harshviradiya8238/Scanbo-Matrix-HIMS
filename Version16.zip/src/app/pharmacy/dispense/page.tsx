import PageTemplate from '@/src/ui/components/PageTemplate';

export default function DispensePage() {
  return <PageTemplate title="Pharmacy Dispense" currentPageTitle="Dispense" />;
}
