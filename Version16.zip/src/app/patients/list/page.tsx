import PatientListPage from '@/src/screens/patients/PatientListPage';

export default function Page() {
  return <PatientListPage />;
}
