import PatientProfilePage from '@/src/screens/patients/PatientProfilePage';

export default function ProfilePage() {
  return <PatientProfilePage />;
}
