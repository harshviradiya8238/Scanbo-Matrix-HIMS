import PageTemplate from '@/src/ui/components/PageTemplate';

export default function DutyRosterPage() {
  return <PageTemplate title="Duty Roster" currentPageTitle="Duty Roster" />;
}
