import OpdPrescriptionsPage from '@/src/screens/opd/OpdPrescriptionsPage';

export default function PrescriptionsPage() {
  return <OpdPrescriptionsPage />;
}
