import OpdOrdersPage from '@/src/screens/opd/OpdOrdersPage';

export default function OrdersPage() {
  return <OpdOrdersPage />;
}
