import ClinicalEpicModulesPage from '@/src/screens/clinical/ClinicalEpicModulesPage';

export default function EpicModulesPage() {
  return <ClinicalEpicModulesPage />;
}
