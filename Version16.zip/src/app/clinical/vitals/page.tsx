import OpdVitalsPage from '@/src/screens/opd/OpdVitalsPage';

export default function VitalsPage() {
  return <OpdVitalsPage />;
}
