import ClinicalEpicModulesPage from '@/src/screens/clinical/ClinicalEpicModulesPage';

export default function ModuleReferencePage() {
  return <ClinicalEpicModulesPage />;
}
