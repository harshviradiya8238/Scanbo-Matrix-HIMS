import OpdNotesPage from '@/src/screens/opd/OpdNotesPage';

export default function NotesPage() {
  return <OpdNotesPage />;
}
