import EpicCareAmbulatoryPage from '@/src/screens/clinical/EpicCareAmbulatoryPage';

export default function EncountersPage() {
  return <EpicCareAmbulatoryPage />;
}
