import * as React from 'react';
import { Button as MuiButton, ButtonProps } from '@mui/material';

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  props,
  ref
) {
  return <MuiButton ref={ref} {...props} />;
});

export type { ButtonProps };
export default Button;
