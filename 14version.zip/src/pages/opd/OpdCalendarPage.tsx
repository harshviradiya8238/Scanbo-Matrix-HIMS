'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import PageTemplate from '@/src/ui/components/PageTemplate';
import { Alert, Box, Button, Chip, MenuItem, Snackbar, Stack, TextField, Typography } from '@/src/ui/components/atoms';
import { Card } from '@/src/ui/components/molecules';
import Grid from '@/src/ui/components/layout/AlignedGrid';
import {
  CalendarMonth as CalendarMonthIcon,
  CheckCircle as CheckCircleIcon,
  Group as GroupIcon,
  PersonAdd as PersonAddIcon,
  WarningAmber as WarningAmberIcon,
} from '@mui/icons-material';
import OpdFlowHeader from './components/OpdFlowHeader';
import {
  AppointmentStatus,
  OPD_APPOINTMENTS,
  OPD_PROVIDERS,
  OpdAppointment,
  VisitType,
} from './opd-mock-data';

interface BookingForm {
  date: string;
  time: string;
  provider: string;
  department: string;
  patientName: string;
  mrn: string;
  ageGender: string;
  phone: string;
  visitType: VisitType;
  payerType: 'General' | 'Insurance' | 'Corporate';
  chiefComplaint: string;
}

type BookingErrors = Partial<Record<keyof BookingForm, string>>;

const appointmentStatusColor: Record<AppointmentStatus, 'default' | 'info' | 'warning' | 'success' | 'error'> = {
  Scheduled: 'default',
  'Checked-In': 'info',
  'In Triage': 'warning',
  'In Consultation': 'warning',
  Completed: 'success',
  'No Show': 'error',
};

function buildDefaultBooking(): BookingForm {
  return {
    date: '2026-02-04',
    time: '11:20',
    provider: OPD_PROVIDERS[0],
    department: 'General Medicine',
    patientName: '',
    mrn: '',
    ageGender: '',
    phone: '',
    visitType: 'New',
    payerType: 'General',
    chiefComplaint: '',
  };
}

export default function OpdCalendarPage() {
  const router = useRouter();
  const [appointments, setAppointments] = React.useState<OpdAppointment[]>(OPD_APPOINTMENTS);
  const [selectedDate, setSelectedDate] = React.useState('2026-02-04');
  const [booking, setBooking] = React.useState<BookingForm>(buildDefaultBooking());
  const [errors, setErrors] = React.useState<BookingErrors>({});
  const [snackbar, setSnackbar] = React.useState<{
    open: boolean;
    message: string;
    severity: 'success' | 'error' | 'info';
  }>({
    open: false,
    message: '',
    severity: 'success',
  });

  const todayAppointments = React.useMemo(
    () => appointments.filter((appointment) => appointment.date === selectedDate),
    [appointments, selectedDate]
  );

  const providerSchedule = React.useMemo(() => {
    return OPD_PROVIDERS.map((provider) => ({
      provider,
      slots: todayAppointments
        .filter((appointment) => appointment.provider === provider)
        .sort((a, b) => a.time.localeCompare(b.time)),
    }));
  }, [todayAppointments]);

  const totalSlots = todayAppointments.length;
  const checkedInCount = todayAppointments.filter((appointment) => appointment.status === 'Checked-In').length;
  const inProgressCount = todayAppointments.filter(
    (appointment) => appointment.status === 'In Triage' || appointment.status === 'In Consultation'
  ).length;
  const noShowCount = todayAppointments.filter((appointment) => appointment.status === 'No Show').length;

  const updateBookingField = <K extends keyof BookingForm>(
    field: K,
    value: BookingForm[K]
  ) => {
    setBooking((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }
  };

  const validateBooking = (): boolean => {
    const nextErrors: BookingErrors = {};
    const requiredFields: Array<[keyof BookingForm, string]> = [
      ['date', 'Date'],
      ['time', 'Time'],
      ['provider', 'Provider'],
      ['department', 'Department'],
      ['patientName', 'Patient name'],
      ['phone', 'Phone'],
      ['visitType', 'Visit type'],
      ['chiefComplaint', 'Chief complaint'],
    ];

    requiredFields.forEach(([field, label]) => {
      if (!booking[field].trim()) {
        nextErrors[field] = `${label} is required`;
      }
    });

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleCreateBooking = (sendToQueue: boolean) => {
    const valid = validateBooking();
    if (!valid) {
      setSnackbar({
        open: true,
        message: 'Please complete all required booking fields.',
        severity: 'error',
      });
      return;
    }

    const created: OpdAppointment = {
      id: `appt-${Date.now()}`,
      date: booking.date,
      time: booking.time,
      provider: booking.provider,
      department: booking.department,
      patientName: booking.patientName,
      mrn: booking.mrn || `MRN-${Math.floor(Math.random() * 900000 + 100000)}`,
      ageGender: booking.ageGender || 'Unknown',
      visitType: booking.visitType,
      status: sendToQueue ? 'Checked-In' : 'Scheduled',
      chiefComplaint: booking.chiefComplaint,
      payerType: booking.payerType,
      phone: booking.phone,
    };

    setAppointments((prev) => [...prev, created].sort((a, b) => a.time.localeCompare(b.time)));

    setSnackbar({
      open: true,
      message: sendToQueue
        ? `Booking created and sent to queue for ${created.patientName}.`
        : `Booking created for ${created.patientName}.`,
      severity: 'success',
    });

    if (sendToQueue) {
      router.push('/appointments/queue');
    }

    setBooking((prev) => ({
      ...buildDefaultBooking(),
      date: prev.date,
      provider: prev.provider,
      department: prev.department,
    }));
  };

  return (
    <PageTemplate title="Appointments Calendar" currentPageTitle="Calendar">
      <Stack spacing={2}>
        <OpdFlowHeader
          activeStep="calendar"
          title="OPD Schedule and Booking"
          description="Manage provider slots, create new bookings, and push arrivals into OPD queue."
          primaryAction={{ label: 'Open Queue', route: '/appointments/queue' }}
        />

        <Grid container spacing={2}>
          <Grid item xs={12} sm={3}>
            <Card
              elevation={0}
              sx={{ p: 2, borderRadius: 2, border: '1px solid', borderColor: 'divider' }}
            >
              <Typography variant="caption" color="text.secondary">
                Slots on {selectedDate}
              </Typography>
              <Typography variant="h4" sx={{ fontWeight: 700 }}>
                {totalSlots}
              </Typography>
            </Card>
          </Grid>
          <Grid item xs={12} sm={3}>
            <Card
              elevation={0}
              sx={{ p: 2, borderRadius: 2, border: '1px solid', borderColor: 'divider' }}
            >
              <Typography variant="caption" color="text.secondary">
                Checked-In
              </Typography>
              <Typography variant="h4" sx={{ fontWeight: 700, color: 'info.main' }}>
                {checkedInCount}
              </Typography>
            </Card>
          </Grid>
          <Grid item xs={12} sm={3}>
            <Card
              elevation={0}
              sx={{ p: 2, borderRadius: 2, border: '1px solid', borderColor: 'divider' }}
            >
              <Typography variant="caption" color="text.secondary">
                In Triage / Consult
              </Typography>
              <Typography variant="h4" sx={{ fontWeight: 700, color: 'warning.main' }}>
                {inProgressCount}
              </Typography>
            </Card>
          </Grid>
          <Grid item xs={12} sm={3}>
            <Card
              elevation={0}
              sx={{ p: 2, borderRadius: 2, border: '1px solid', borderColor: 'divider' }}
            >
              <Typography variant="caption" color="text.secondary">
                No Show
              </Typography>
              <Typography variant="h4" sx={{ fontWeight: 700, color: 'error.main' }}>
                {noShowCount}
              </Typography>
            </Card>
          </Grid>
        </Grid>

        <Grid container spacing={2}>
          <Grid item xs={12} lg={7.5}>
            <Card
              elevation={0}
              sx={{ p: 2, borderRadius: 2, border: '1px solid', borderColor: 'divider' }}
            >
              <Stack spacing={1.5}>
                <Stack
                  direction={{ xs: 'column', md: 'row' }}
                  spacing={1.25}
                  alignItems={{ xs: 'flex-start', md: 'center' }}
                  justifyContent="space-between"
                >
                  <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
                    Provider Schedule Board
                  </Typography>
                  <TextField
                    label="Schedule Date"
                    type="date"
                    value={selectedDate}
                    onChange={(event) => setSelectedDate(event.target.value)}
                    size="small"
                    InputLabelProps={{ shrink: true }}
                  />
                </Stack>

                {providerSchedule.map((providerBlock) => (
                  <Card key={providerBlock.provider} variant="outlined" sx={{ p: 1.5, borderRadius: 1.5 }}>
                    <Stack spacing={1}>
                      <Stack direction="row" justifyContent="space-between" alignItems="center">
                        <Typography variant="body2" sx={{ fontWeight: 700 }}>
                          {providerBlock.provider}
                        </Typography>
                        <Chip size="small" label={`${providerBlock.slots.length} slots`} />
                      </Stack>

                      {providerBlock.slots.length === 0 ? (
                        <Typography variant="caption" color="text.secondary">
                          No bookings for this date.
                        </Typography>
                      ) : (
                        providerBlock.slots.map((slot) => (
                          <Stack
                            key={slot.id}
                            direction={{ xs: 'column', md: 'row' }}
                            spacing={1}
                            justifyContent="space-between"
                            sx={{
                              py: 0.75,
                              borderBottom: '1px dashed',
                              borderColor: 'divider',
                            }}
                          >
                            <Typography variant="body2" sx={{ fontWeight: 600 }}>
                              {slot.time} · {slot.patientName} ({slot.mrn})
                            </Typography>
                            <Stack direction="row" spacing={0.8}>
                              <Chip size="small" variant="outlined" label={slot.visitType} />
                              <Chip
                                size="small"
                                color={appointmentStatusColor[slot.status]}
                                label={slot.status}
                              />
                            </Stack>
                          </Stack>
                        ))
                      )}
                    </Stack>
                  </Card>
                ))}
              </Stack>
            </Card>
          </Grid>

          <Grid item xs={12} lg={4.5}>
            <Card
              elevation={0}
              sx={{ p: 2, borderRadius: 2, border: '1px solid', borderColor: 'divider' }}
            >
              <Stack spacing={1.3}>
                <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
                  New Booking
                </Typography>

                <Grid container spacing={1.2}>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      label="Date"
                      type="date"
                      value={booking.date}
                      onChange={(event) => updateBookingField('date', event.target.value)}
                      error={Boolean(errors.date)}
                      helperText={errors.date}
                      InputLabelProps={{ shrink: true }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      label="Time"
                      type="time"
                      value={booking.time}
                      onChange={(event) => updateBookingField('time', event.target.value)}
                      error={Boolean(errors.time)}
                      helperText={errors.time}
                      InputLabelProps={{ shrink: true }}
                    />
                  </Grid>
                </Grid>

                <TextField
                  select
                  label="Provider"
                  value={booking.provider}
                  onChange={(event) => updateBookingField('provider', event.target.value)}
                  error={Boolean(errors.provider)}
                  helperText={errors.provider}
                >
                  {OPD_PROVIDERS.map((provider) => (
                    <MenuItem key={provider} value={provider}>
                      {provider}
                    </MenuItem>
                  ))}
                </TextField>

                <TextField
                  label="Department"
                  value={booking.department}
                  onChange={(event) => updateBookingField('department', event.target.value)}
                  error={Boolean(errors.department)}
                  helperText={errors.department}
                />

                <TextField
                  label="Patient Name"
                  value={booking.patientName}
                  onChange={(event) => updateBookingField('patientName', event.target.value)}
                  error={Boolean(errors.patientName)}
                  helperText={errors.patientName}
                />

                <Grid container spacing={1.2}>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      label="MRN (optional)"
                      value={booking.mrn}
                      onChange={(event) => updateBookingField('mrn', event.target.value)}
                      fullWidth
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      label="Age / Gender"
                      value={booking.ageGender}
                      onChange={(event) => updateBookingField('ageGender', event.target.value)}
                      fullWidth
                    />
                  </Grid>
                </Grid>

                <TextField
                  label="Phone"
                  value={booking.phone}
                  onChange={(event) => updateBookingField('phone', event.target.value)}
                  error={Boolean(errors.phone)}
                  helperText={errors.phone}
                />

                <Grid container spacing={1.2}>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      select
                      label="Visit Type"
                      value={booking.visitType}
                      onChange={(event) => updateBookingField('visitType', event.target.value as VisitType)}
                    >
                      {['New', 'Follow-up', 'Review'].map((option) => (
                        <MenuItem key={option} value={option}>
                          {option}
                        </MenuItem>
                      ))}
                    </TextField>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      select
                      label="Payer"
                      value={booking.payerType}
                      onChange={(event) =>
                        updateBookingField(
                          'payerType',
                          event.target.value as 'General' | 'Insurance' | 'Corporate'
                        )
                      }
                    >
                      {['General', 'Insurance', 'Corporate'].map((option) => (
                        <MenuItem key={option} value={option}>
                          {option}
                        </MenuItem>
                      ))}
                    </TextField>
                  </Grid>
                </Grid>

                <TextField
                  label="Chief Complaint"
                  multiline
                  minRows={2}
                  value={booking.chiefComplaint}
                  onChange={(event) => updateBookingField('chiefComplaint', event.target.value)}
                  error={Boolean(errors.chiefComplaint)}
                  helperText={errors.chiefComplaint}
                />

                <Stack direction="row" spacing={1.2}>
                  <Button
                    variant="outlined"
                    startIcon={<PersonAddIcon />}
                    onClick={() => handleCreateBooking(false)}
                  >
                    Create Booking
                  </Button>
                  <Button
                    variant="contained"
                    color="success"
                    startIcon={<GroupIcon />}
                    onClick={() => handleCreateBooking(true)}
                  >
                    Create + Check-In
                  </Button>
                </Stack>
              </Stack>
            </Card>
          </Grid>
        </Grid>

        <Card elevation={0} sx={{ p: 2, borderRadius: 2, border: '1px solid', borderColor: 'divider' }}>
          <Stack
            direction={{ xs: 'column', md: 'row' }}
            spacing={1.2}
            justifyContent="space-between"
            alignItems={{ xs: 'flex-start', md: 'center' }}
          >
            <Box>
              <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
                OPD Flow Quick Actions
              </Typography>
              <Typography variant="caption" color="text.secondary">
                Continue to queue and encounter once patient checks in.
              </Typography>
            </Box>
            <Stack direction="row" spacing={1}>
              <Button variant="outlined" startIcon={<CalendarMonthIcon />} onClick={() => router.push('/appointments/queue')}>
                Queue Desk
              </Button>
              <Button variant="outlined" startIcon={<CheckCircleIcon />} onClick={() => router.push('/appointments/visit')}>
                Visit Workspace
              </Button>
              <Button variant="text" startIcon={<WarningAmberIcon />} onClick={() => router.push('/clinical/orders')}>
                Clinical Orders
              </Button>
            </Stack>
          </Stack>
        </Card>

        <Snackbar
          open={snackbar.open}
          autoHideDuration={3500}
          onClose={() => setSnackbar((prev) => ({ ...prev, open: false }))}
          anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        >
          <Alert
            onClose={() => setSnackbar((prev) => ({ ...prev, open: false }))}
            severity={snackbar.severity}
            sx={{ width: '100%' }}
          >
            {snackbar.message}
          </Alert>
        </Snackbar>
      </Stack>
    </PageTemplate>
  );
}
