import PageTemplate from '@/src/ui/components/PageTemplate';

export default function DocumentsPage() {
  return <PageTemplate title="Patient Documents" currentPageTitle="Documents" />;
}
