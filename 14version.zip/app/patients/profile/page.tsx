import PageTemplate from '@/src/ui/components/PageTemplate';

export default function ProfilePage() {
  return <PageTemplate title="Patient Profile" currentPageTitle="Profile" />;
}
