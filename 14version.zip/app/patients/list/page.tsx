import dynamic from 'next/dynamic';
import LoadingSpinner from '@/src/ui/components/LoadingSpinner';

const PatientListPage = dynamic(() => import('@/src/pages/patients/PatientListPage'), {
  loading: () => <LoadingSpinner message="Loading..." />,
});

export default function Page() {
  return <PatientListPage />;
}
