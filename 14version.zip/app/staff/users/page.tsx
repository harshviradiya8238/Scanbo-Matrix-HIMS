import PageTemplate from '@/src/ui/components/PageTemplate';

export default function UsersPage() {
  return <PageTemplate title="Staff Users" currentPageTitle="Users" />;
}
