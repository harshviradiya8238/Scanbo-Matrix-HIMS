import PageTemplate from '@/src/ui/components/PageTemplate';

export default function RolesPage() {
  return <PageTemplate title="Roles & Permissions" currentPageTitle="Roles" />;
}
