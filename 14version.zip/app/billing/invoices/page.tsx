import PageTemplate from '@/src/ui/components/PageTemplate';

export default function InvoicesPage() {
  return <PageTemplate title="Billing Invoices" currentPageTitle="Invoices" />;
}
