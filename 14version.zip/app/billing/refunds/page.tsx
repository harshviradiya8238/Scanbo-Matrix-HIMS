import PageTemplate from '@/src/ui/components/PageTemplate';

export default function RefundsPage() {
  return <PageTemplate title="Billing Refunds" currentPageTitle="Refunds" />;
}
