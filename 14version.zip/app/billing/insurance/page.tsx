import PageTemplate from '@/src/ui/components/PageTemplate';

export default function InsurancePage() {
  return <PageTemplate title="Insurance / TPA" currentPageTitle="Insurance" />;
}
