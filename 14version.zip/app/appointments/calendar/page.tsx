import dynamic from 'next/dynamic';
import LoadingSpinner from '@/src/ui/components/LoadingSpinner';

const OpdCalendarPage = dynamic(() => import('@/src/pages/opd/OpdCalendarPage'), {
  loading: () => <LoadingSpinner message="Loading..." />,
});

export default function CalendarPage() {
  return <OpdCalendarPage />;
}
