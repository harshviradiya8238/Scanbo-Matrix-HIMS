import dynamic from 'next/dynamic';
import LoadingSpinner from '@/src/ui/components/LoadingSpinner';

const OpdVisitPage = dynamic(() => import('@/src/pages/opd/OpdVisitPage'), {
  loading: () => <LoadingSpinner message="Loading..." />,
});

export default function VisitPage() {
  return <OpdVisitPage />;
}
