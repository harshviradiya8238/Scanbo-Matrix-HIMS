import dynamic from 'next/dynamic';
import LoadingSpinner from '@/src/ui/components/LoadingSpinner';

const OpdQueuePage = dynamic(() => import('@/src/pages/opd/OpdQueuePage'), {
  loading: () => <LoadingSpinner message="Loading..." />,
});

export default function QueuePage() {
  return <OpdQueuePage />;
}
