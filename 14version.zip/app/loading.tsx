import LoadingSpinner from '@/src/ui/components/LoadingSpinner';

export default function Loading() {
  return <LoadingSpinner fullScreen message="Loading..." />;
}
