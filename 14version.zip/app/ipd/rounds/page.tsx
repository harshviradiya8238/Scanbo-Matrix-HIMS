import dynamic from 'next/dynamic';
import LoadingSpinner from '@/src/ui/components/LoadingSpinner';

const InpatientClinDocPage = dynamic(() => import('@/src/pages/clinical/InpatientClinDocPage'), {
  loading: () => <LoadingSpinner message="Loading..." />,
});

export default function RoundsPage() {
  return <InpatientClinDocPage />;
}
