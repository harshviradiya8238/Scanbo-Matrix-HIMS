import dynamic from 'next/dynamic';
import LoadingSpinner from '@/src/ui/components/LoadingSpinner';

const IpdDischargePage = dynamic(() => import('@/src/pages/ipd/IpdDischargePage'), {
  loading: () => <LoadingSpinner message="Loading..." />,
});

export default function DischargePage() {
  return <IpdDischargePage />;
}
