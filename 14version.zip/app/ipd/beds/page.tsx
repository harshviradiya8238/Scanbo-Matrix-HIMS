import dynamic from 'next/dynamic';
import LoadingSpinner from '@/src/ui/components/LoadingSpinner';

const IpdBedManagementPage = dynamic(() => import('@/src/pages/ipd/IpdBedManagementPage'), {
  loading: () => <LoadingSpinner message="Loading..." />,
});

export default function BedsPage() {
  return <IpdBedManagementPage />;
}
