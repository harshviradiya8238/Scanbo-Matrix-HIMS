import dynamic from 'next/dynamic';
import LoadingSpinner from '@/src/ui/components/LoadingSpinner';

const IpdAdmissionsPage = dynamic(() => import('@/src/pages/ipd/IpdAdmissionsPage'), {
  loading: () => <LoadingSpinner message="Loading..." />,
});

export default function AdmissionsPage() {
  return <IpdAdmissionsPage />;
}
