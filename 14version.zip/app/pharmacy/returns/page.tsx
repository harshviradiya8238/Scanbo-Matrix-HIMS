import PageTemplate from '@/src/ui/components/PageTemplate';

export default function ReturnsPage() {
  return <PageTemplate title="Pharmacy Returns" currentPageTitle="Returns" />;
}
