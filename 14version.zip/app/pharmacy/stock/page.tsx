import PageTemplate from '@/src/ui/components/PageTemplate';

export default function StockPage() {
  return <PageTemplate title="Pharmacy Stock" currentPageTitle="Stock" />;
}
