import PageTemplate from '@/src/ui/components/PageTemplate';

export default function BillingReportsPage() {
  return <PageTemplate title="Billing Reports" currentPageTitle="Billing Reports" />;
}
