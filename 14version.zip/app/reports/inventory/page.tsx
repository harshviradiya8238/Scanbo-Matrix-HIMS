import PageTemplate from '@/src/ui/components/PageTemplate';

export default function InventoryReportsPage() {
  return <PageTemplate title="Inventory Reports" currentPageTitle="Inventory Reports" />;
}
