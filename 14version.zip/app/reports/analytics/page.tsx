import PageTemplate from '@/src/ui/components/PageTemplate';

export default function AnalyticsPage() {
  return <PageTemplate title="Analytics Dashboard" currentPageTitle="Analytics" />;
}
