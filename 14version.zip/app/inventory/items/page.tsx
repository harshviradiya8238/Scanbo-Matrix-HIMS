import PageTemplate from '@/src/ui/components/PageTemplate';

export default function ItemsPage() {
  return <PageTemplate title="Inventory Items" currentPageTitle="Items" />;
}
