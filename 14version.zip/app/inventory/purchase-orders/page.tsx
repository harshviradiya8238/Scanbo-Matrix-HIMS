import PageTemplate from '@/src/ui/components/PageTemplate';

export default function PurchaseOrdersPage() {
  return <PageTemplate title="Purchase Orders" currentPageTitle="Purchase Orders" />;
}
