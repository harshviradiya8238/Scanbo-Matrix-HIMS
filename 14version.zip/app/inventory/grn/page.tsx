import PageTemplate from '@/src/ui/components/PageTemplate';

export default function GRNPage() {
  return <PageTemplate title="GRN (Goods Receipt Note)" currentPageTitle="GRN" />;
}
