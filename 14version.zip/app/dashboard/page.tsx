import dynamic from 'next/dynamic';
import LoadingSpinner from '@/src/ui/components/LoadingSpinner';

const DashboardPage = dynamic(() => import('@/src/pages/dashboard/DashboardPage'), {
  loading: () => <LoadingSpinner message="Loading..." />,
});

export default function DashboardRoutePage() {
  return <DashboardPage />;
}
