import PageTemplate from '@/src/ui/components/PageTemplate';

export default function ProcedureOrdersPage() {
  return <PageTemplate title="Procedure Orders" currentPageTitle="Procedure Orders" />;
}
