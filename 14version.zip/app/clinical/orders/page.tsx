import dynamic from 'next/dynamic';
import LoadingSpinner from '@/src/ui/components/LoadingSpinner';

const OpdOrdersPage = dynamic(() => import('@/src/pages/opd/OpdOrdersPage'), {
  loading: () => <LoadingSpinner message="Loading..." />,
});

export default function OrdersPage() {
  return <OpdOrdersPage />;
}
