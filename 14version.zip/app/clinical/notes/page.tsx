import dynamic from 'next/dynamic';
import LoadingSpinner from '@/src/ui/components/LoadingSpinner';

const OpdNotesPage = dynamic(() => import('@/src/pages/opd/OpdNotesPage'), {
  loading: () => <LoadingSpinner message="Loading..." />,
});

export default function NotesPage() {
  return <OpdNotesPage />;
}
