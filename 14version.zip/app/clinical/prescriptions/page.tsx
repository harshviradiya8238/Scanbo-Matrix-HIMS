import dynamic from 'next/dynamic';
import LoadingSpinner from '@/src/ui/components/LoadingSpinner';

const OpdPrescriptionsPage = dynamic(() => import('@/src/pages/opd/OpdPrescriptionsPage'), {
  loading: () => <LoadingSpinner message="Loading..." />,
});

export default function PrescriptionsPage() {
  return <OpdPrescriptionsPage />;
}
