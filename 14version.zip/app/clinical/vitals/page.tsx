import dynamic from 'next/dynamic';
import LoadingSpinner from '@/src/ui/components/LoadingSpinner';

const OpdVitalsPage = dynamic(() => import('@/src/pages/opd/OpdVitalsPage'), {
  loading: () => <LoadingSpinner message="Loading..." />,
});

export default function VitalsPage() {
  return <OpdVitalsPage />;
}
