import dynamic from 'next/dynamic';
import LoadingSpinner from '@/src/ui/components/LoadingSpinner';

const EpicCareAmbulatoryPage = dynamic(() => import('@/src/pages/clinical/EpicCareAmbulatoryPage'), {
  loading: () => <LoadingSpinner message="Loading..." />,
});

export default function EncountersPage() {
  return <EpicCareAmbulatoryPage />;
}
