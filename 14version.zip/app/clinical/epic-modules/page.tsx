import dynamic from 'next/dynamic';
import LoadingSpinner from '@/src/ui/components/LoadingSpinner';

const ClinicalEpicModulesPage = dynamic(() => import('@/src/pages/clinical/ClinicalEpicModulesPage'), {
  loading: () => <LoadingSpinner message="Loading..." />,
});

export default function EpicModulesPage() {
  return <ClinicalEpicModulesPage />;
}

