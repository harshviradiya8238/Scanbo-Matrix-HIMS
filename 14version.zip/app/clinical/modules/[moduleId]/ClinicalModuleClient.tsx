'use client';

import dynamic from 'next/dynamic';
import LoadingSpinner from '@/src/ui/components/LoadingSpinner';
import ClinicalModulePlaceholderPage from '@/src/pages/clinical/ClinicalModulePlaceholderPage';
import { ClinicalModuleDefinition } from '@/src/pages/clinical/module-registry';

const EpicCareAmbulatoryPage = dynamic(
  () => import('@/src/pages/clinical/EpicCareAmbulatoryPage'),
  {
    ssr: false,
    loading: () => <LoadingSpinner message="Loading clinical module..." />,
  }
);

const InpatientClinDocPage = dynamic(
  () => import('@/src/pages/clinical/InpatientClinDocPage'),
  {
    ssr: false,
    loading: () => <LoadingSpinner message="Loading clinical module..." />,
  }
);

const WelcomeKioskPage = dynamic(
  () => import('@/src/pages/clinical/WelcomeKioskPage'),
  {
    ssr: false,
    loading: () => <LoadingSpinner message="Loading clinical module..." />,
  }
);

const CareCompanionPage = dynamic(
  () => import('@/src/pages/clinical/CareCompanionPage'),
  {
    ssr: false,
    loading: () => <LoadingSpinner message="Loading clinical module..." />,
  }
);

const InfectionControlPage = dynamic(
  () => import('@/src/pages/clinical/InfectionControlPage'),
  {
    ssr: false,
    loading: () => <LoadingSpinner message="Loading clinical module..." />,
  }
);

interface ClinicalModuleClientProps {
  moduleDefinition: ClinicalModuleDefinition;
}

export default function ClinicalModuleClient({ moduleDefinition }: ClinicalModuleClientProps) {
  if (moduleDefinition.slug === 'ambulatory-care-opd') {
    return <EpicCareAmbulatoryPage />;
  }

  if (moduleDefinition.slug === 'inpatient-documentation-clindoc') {
    return <InpatientClinDocPage />;
  }

  if (moduleDefinition.slug === 'welcome-kiosk') {
    return <WelcomeKioskPage />;
  }

  if (moduleDefinition.slug === 'care-companion') {
    return <CareCompanionPage />;
  }

  if (moduleDefinition.slug === 'bugsy-infection-control') {
    return <InfectionControlPage />;
  }

  return <ClinicalModulePlaceholderPage moduleDefinition={moduleDefinition} />;
}
