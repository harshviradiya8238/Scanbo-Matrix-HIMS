import { notFound } from 'next/navigation';
import { getClinicalModuleBySlug } from '@/src/pages/clinical/module-registry';
import ClinicalModuleClient from './ClinicalModuleClient';

export default function ClinicalModulePage({
  params,
}: {
  params: { moduleId: string };
}) {
  const moduleDefinition = getClinicalModuleBySlug(params.moduleId);

  if (!moduleDefinition) {
    notFound();
  }

  return <ClinicalModuleClient moduleDefinition={moduleDefinition} />;
}
