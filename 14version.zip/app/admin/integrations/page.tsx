import PageTemplate from '@/src/ui/components/PageTemplate';

export default function IntegrationsPage() {
  return <PageTemplate title="Integrations" currentPageTitle="Integrations" />;
}
