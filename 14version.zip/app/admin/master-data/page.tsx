import PageTemplate from '@/src/ui/components/PageTemplate';

export default function MasterDataPage() {
  return <PageTemplate title="Master Data" currentPageTitle="Master Data" />;
}
