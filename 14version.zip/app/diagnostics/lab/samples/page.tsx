import PageTemplate from '@/src/ui/components/PageTemplate';

export default function SamplesPage() {
  return <PageTemplate title="Lab Samples" currentPageTitle="Samples" />;
}
